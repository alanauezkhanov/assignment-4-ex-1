import java.util.List;

class NutritionPlan {
    private int caloricIntake;
    private int[] macronutrientRatios;
    private List<String> mealPlans;
    private String fitnessGoal;
    private List<String> dietaryRestrictions;

    public void setCaloricIntake(int caloricIntake) {
        this.caloricIntake = caloricIntake;
    }

    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        this.macronutrientRatios = new int[]{carbohydrates, proteins, fats};
    }

    public void setMealPlans(List<String> mealPlans) {
        this.mealPlans = mealPlans;
    }

    public void setFitnessGoal(String fitnessGoal) {
        this.fitnessGoal = fitnessGoal;
    }

    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
        this.dietaryRestrictions = dietaryRestrictions;
    }

    @Override
    public String toString() {
        return "Nutrition Plan:\n" +
                "Caloric Intake: " + caloricIntake + "\n" +
                "Macronutrient Ratios: " + macronutrientRatios[0] + ":" +
                macronutrientRatios[1] + ":" + macronutrientRatios[2] + "\n" +
                "Meal Plans: " + mealPlans + "\n" +
                "Fitness Goal: " + fitnessGoal + "\n" +
                "Dietary Restrictions: " + dietaryRestrictions;
    }
}

interface NutritionPlanBuilder {
    void setCaloricIntake(int caloricIntake);
    void setMacronutrientRatios(int carbohydrates, int proteins, int fats);
    void setMealPlans(List<String> mealPlans);
    void setFitnessGoal(String fitnessGoal);
    void setDietaryRestrictions(List<String> dietaryRestrictions);
    NutritionPlan build();
}

class NutritionPlanDirector {
    private NutritionPlanBuilder builder;

    public void setBuilder(NutritionPlanBuilder builder) {
        this.builder = builder;
    }

    public void createNutritionPlan() {
        builder.setCaloricIntake(2000);
        builder.setMacronutrientRatios(40, 30, 30);
        builder.setMealPlans(List.of("Breakfast: Oatmeal", "Lunch: Grilled Chicken Salad", "Dinner: Salmon with Quinoa"));
        builder.setFitnessGoal("weight loss");
        builder.setDietaryRestrictions(List.of("gluten-free"));
    }
}

// Step 4: Create concrete builder classes
class WeightLossNutritionPlanBuilder implements NutritionPlanBuilder {
    private NutritionPlan nutritionPlan;

    public WeightLossNutritionPlanBuilder() {
        nutritionPlan = new NutritionPlan();
    }

    @Override
    public void setCaloricIntake(int caloricIntake) {
        nutritionPlan.setCaloricIntake(caloricIntake);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        nutritionPlan.setMacronutrientRatios(carbohydrates, proteins, fats);
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        nutritionPlan.setMealPlans(mealPlans);
    }

    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal(fitnessGoal);
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
        nutritionPlan.setDietaryRestrictions(dietaryRestrictions);
    }

    @Override
    public NutritionPlan build() {
        return nutritionPlan;
    }
}

abstract class WeightGainNutritionPlanBuilder implements NutritionPlanBuilder {
    private NutritionPlan nutritionPlan;

    public WeightGainNutritionPlanBuilder() {
        nutritionPlan = new NutritionPlan();
    }

    @Override
    public void setCaloricIntake(int caloricIntake) {
        nutritionPlan.setCaloricIntake(caloricIntake);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        nutritionPlan.setMacronutrientRatios(carbohydrates, proteins, fats);
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        nutritionPlan.setMealPlans(mealPlans);
    }

    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal(fitnessGoal);
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
        nutritionPlan.setDietaryRestrictions(dietaryRestrictions);
    }

    @Override
    public NutritionPlan build() {
        return nutritionPlan;
    }
}

abstract class MaintenanceNutritionPlanBuilder implements NutritionPlanBuilder {
    private NutritionPlan nutritionPlan;

    public MaintenanceNutritionPlanBuilder() {
        nutritionPlan = new NutritionPlan();
    }

    @Override
    public void setCaloricIntake(int caloricIntake) {
        nutritionPlan.setCaloricIntake(caloricIntake);
    }

    @Override
    public void setMacronutrientRatios(int carbohydrates, int proteins, int fats) {
        nutritionPlan.setMacronutrientRatios(carbohydrates, proteins, fats);
    }

    @Override
    public void setMealPlans(List<String> mealPlans) {
        nutritionPlan.setMealPlans(mealPlans);
    }

    @Override
    public void setFitnessGoal(String fitnessGoal) {
        nutritionPlan.setFitnessGoal(fitnessGoal);
    }

    @Override
    public void setDietaryRestrictions(List<String> dietaryRestrictions) {
        nutritionPlan.setDietaryRestrictions(dietaryRestrictions);
    }

    @Override
    public NutritionPlan build() {
        return nutritionPlan;
    }
}


public class Main {
    public static void main(String[] args) {
        NutritionPlanDirector director = new NutritionPlanDirector();

        NutritionPlanBuilder builder = new WeightLossNutritionPlanBuilder();

        director.setBuilder(builder);

        director.createNutritionPlan();

        NutritionPlan nutritionPlan = builder.build();

        System.out.println(nutritionPlan);
    }
}
